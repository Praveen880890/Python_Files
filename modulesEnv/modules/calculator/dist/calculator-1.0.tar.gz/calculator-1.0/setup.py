from setuptools import setup

setup(name= "calculator",
      version = '1.0',
      description = 'My new python module',
      author = 'Praveen',
      author_email='s.praveen8233@gmail.com',
      url = 'google.com',
      py_modules = ['calculator'],)
